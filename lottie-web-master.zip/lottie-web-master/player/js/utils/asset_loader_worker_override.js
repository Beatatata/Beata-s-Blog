var assetLoader = null;
