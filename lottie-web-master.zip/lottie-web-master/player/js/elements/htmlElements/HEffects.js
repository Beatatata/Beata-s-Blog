function HEffects() {
}
HEffects.prototype.renderFrame = function(){};