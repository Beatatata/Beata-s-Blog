function ShapeElementData() {
	
}